NUnit 2.5.7.10213
=================

You no longer have to install NUnit to build the C# Driver. The files necessary for building have been copied to the lib directory below this one.

You will have to install NUnit to run the unit tests (unless you are using a different test runner).

The NUnit-2.5.7.10213.msi file in this directory is a copy of the file of the same name available at:

http://nunit.org/?p=download
