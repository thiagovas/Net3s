## MongoDB C# Driver

driver home: http://github.com/mongodb/mongo-csharp-driver

mongodb home: http://www.mongodb.org/

apidoc: http://api.mongodb.org/csharp/ (coming soon)

### Questions and Bug Reports

 * mailing list: http://groups.google.com/group/mongodb-user
 * jira: http://jira.mongodb.org/

### Change Log

http://jira.mongodb.org/browse/CSHARP

see also: BreakingChanges.txt

### Maintainers:
* Robert Stam           robert@10gen.com
* Sridhar Nanjundeswaran    sridhar@10gen.com

### Contributors:
* Justin Dearing        zippy1981@gmail.com
* Teun Duynstee		teun@duynstee.com
* Ken Egozi             mail@kenegozi.com
* Simon Green		simon@captaincodeman.com
* Richard Kreuter       richard@10gen.com
* Kevin Lewis		kevin.l.lewis@gmail.com
* Andrew Rondeau	github@andrewrondeau.com
* Ed Rooth          edward.rooth@wallstreetjapan.com
* Testo                 test1@doramail.com   
* Craig Wilson          craiggwilson@gmail.com

If you have contributed and I have neglected to add you to this list please contact me at robert@10gen.com to be added to the list (with apologies).
