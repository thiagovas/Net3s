﻿namespace MongoDB.Linq.Expressions
{
    internal enum AggregateType
    {
        Count,
        Min,
        Max,
        Average,
        Sum
    }
}
