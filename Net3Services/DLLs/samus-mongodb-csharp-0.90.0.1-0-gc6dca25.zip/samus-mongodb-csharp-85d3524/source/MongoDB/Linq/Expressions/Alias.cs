﻿namespace MongoDB.Linq.Expressions
{
    internal sealed class Alias
    { }
}