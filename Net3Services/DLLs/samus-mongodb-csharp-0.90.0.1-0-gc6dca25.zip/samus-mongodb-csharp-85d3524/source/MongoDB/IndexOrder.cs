﻿namespace MongoDB
{
    /// <summary>
    /// 
    /// </summary>
    public enum IndexOrder {
        /// <summary>
        /// 
        /// </summary>
        Descending = -1,
        /// <summary>
        /// 
        /// </summary>
        Ascending = 1
    }
}